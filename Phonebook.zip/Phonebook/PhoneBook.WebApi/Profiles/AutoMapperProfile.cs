﻿using AutoMapper;
using Phonebook.Model;
using PhoneBook.WebApi.Model;

namespace PhoneBook.WebApi.Profiles
{
    public class AutoMapperProfile : Profile
    {
        /// <summary>
        /// Help us map view model and data objects
        /// </summary>
        public AutoMapperProfile()
        {
            CreateMap<Contact, ContactViewModel>()
              .ReverseMap();
        }
    }
}
