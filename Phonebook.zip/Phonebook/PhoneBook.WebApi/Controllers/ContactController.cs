﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Phonebook.Business.Interface;
using Phonebook.Business.Manager;
using Phonebook.Model;
using PhoneBook.WebApi.Model;

namespace PhoneBook.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("absaapi/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        public readonly IContactManager _contactManager;

        public ContactController(IContactManager contactManager)
            : base()
        {
            this._contactManager = contactManager;
        }
        
        [HttpGet]
        public IEnumerable<ContactViewModel> GetAllContacts()
        {
            try
            {
                var contacts = _contactManager.GetAllContacts().ToList();
                var contactsViewModelResults = Mapper.Map<List<Contact>, List<ContactViewModel>>(contacts);
                return contactsViewModelResults;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpGet("{id}", Name = "Get")]
        public ContactViewModel GetContactById(int id)
        {
            try
            {
                var contact = _contactManager.GetContactById(id);
                var contactViewModelResults = Mapper.Map<Contact,ContactViewModel>(contact);
                return contactViewModelResults;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpPost]
        public void Post([FromBody] ContactViewModel contactViewModel)
        {
            try
            {
                try
                {
                    var contact = Mapper.Map<ContactViewModel, Contact>(contactViewModel);
                    //Add records if Id is 0 else update
                    if(contactViewModel.Id == 0)
                        _contactManager.AddContact(contact);
                    else
                        _contactManager.UpdateContact(contact);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        [HttpDelete]
        public void Delete(int id)
        {
            try
            {
                var contact = _contactManager.DeleteContact(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
