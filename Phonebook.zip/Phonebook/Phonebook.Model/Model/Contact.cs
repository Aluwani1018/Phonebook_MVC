﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Phonebook.Model
{
    public class Contact : BaseModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
    }
}
