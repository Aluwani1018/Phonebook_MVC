﻿
namespace Phonebook.Model
{
    public abstract class BaseModel
    {
        public int Id { get; set; }
    }
}
