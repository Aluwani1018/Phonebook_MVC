﻿using Phonebook.Data;
using Phonebook.Model;
using System.Collections.Generic;
using Phonebook.Business.Interface;

namespace Phonebook.Business.Manager
{
    /// <summary>
    /// This is where we write our our contact busines logic
    /// using the UnitOfWork
    /// </summary>
    public class ContactManager : IContactManager
    {
        private readonly IUnitOfWork _unitOfWork;

        #region Ctor(s)
        public ContactManager(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region Method(s)

        public int AddContact(Contact contact)
        {
            _unitOfWork.Contacts.Add(contact);
            return _unitOfWork.Save();
        }

        public int UpdateContact(Contact contact)
        {
            _unitOfWork.Contacts.Update(contact);
            return _unitOfWork.Save();
        }

        public int DeleteContact(int id)
        {
            var contact = GetContactById(id);
            _unitOfWork.Contacts.Delete(contact);
            return _unitOfWork.Save();
        }

        public Contact GetContactById(int id)
        {
            return _unitOfWork.Contacts.GetById(id);
        }

        public IEnumerable<Contact> GetAllContacts()
        {
            return _unitOfWork.Contacts.GetAll();
        }

        public IEnumerable<Contact> SearchContact(string Name)
        {
            return _unitOfWork.Contacts.GetWhere(x => x.FirstName == Name || x.LastName == Name);
        } 
        #endregion
    }
}
