﻿using Phonebook.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Phonebook.Business.Interface
{
    public interface IContactManager
    {
        int AddContact(Contact contact);
        int UpdateContact(Contact contact);
        int DeleteContact(int id);
        Contact GetContactById(int id);
        IEnumerable<Contact> GetAllContacts();
        IEnumerable<Contact> SearchContact(string Name);
    }
}
