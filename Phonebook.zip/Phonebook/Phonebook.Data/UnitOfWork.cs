﻿using Phonebook.Data.Interfaces;
using Phonebook.Data.Repositories;
using Phonebook.Model;
using System;

namespace Phonebook.Data
{
    /// <summary>
    /// This is used to group repository, so that we can don't have to access them directly
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext dbContext = null;
        public UnitOfWork(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext as ApplicationDbContext;
        }

        public IContactRepository Contacts
        {
            get { return new ContactRepository(dbContext); }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (dbContext != null)
                {
                    dbContext.Dispose();
                }
            }
        }
        public int Save()
        {
            return dbContext.SaveChanges();
        }
    }
}
