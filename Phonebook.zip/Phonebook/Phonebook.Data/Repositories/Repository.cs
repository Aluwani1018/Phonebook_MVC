﻿using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using Phonebook.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using Phonebook.Model;
using System;

namespace Phonebook.Data.Repositories
{
    /// <summary>
    /// Built a CRUD methods so that we can re-use them if we happen to work with multiple objects
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        protected internal ApplicationDbContext DbContext = null;
        protected internal DbSet<TEntity> DbSet;

        #region Ctor(s)
        public Repository(DbContext dbContext)
        {
            if (dbContext == null)
                throw new ArgumentNullException("dbContext");
            DbContext = dbContext as ApplicationDbContext;
            DbSet = DbContext.Set<TEntity>();
        }

        #endregion

        #region Method(s)
        public void Add(TEntity entity)
        {
            var dbEntityEntry = DbContext.Entry(entity);
            if (dbEntityEntry.State != EntityState.Detached)
            {
                dbEntityEntry.State = EntityState.Added;
            }
            else
            {
                DbSet.Add(entity);
            }
        }

        public virtual void Update(TEntity entity)
        {
            var dbEntityEntry = DbContext.Entry(entity);

            if (dbEntityEntry.State == EntityState.Detached)
            {
                DbSet.Attach(entity);
            }

            dbEntityEntry.State = EntityState.Modified;
        }

        public virtual void Delete(TEntity entity)
        {
            var dbEntityEntry = DbContext.Entry(entity);

            if (dbEntityEntry.State == EntityState.Detached)
            {
                DbSet.Remove(entity);
            }

            dbEntityEntry.State = EntityState.Deleted;
        }

        public TEntity GetById(int id)
        {
            return DbSet.Find(id);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return DbSet.AsQueryable().AsNoTracking().ToList();
        }
        public IEnumerable<TEntity> GetWhere(Expression<Func<TEntity, bool>> where)
        {
            IQueryable<TEntity> query = DbSet;
            var results = query.Where(where).AsQueryable();
            return results.AsNoTracking().ToList().ToList();
        } 
        #endregion
    }
}
