﻿using Phonebook.Model;
using Phonebook.Data.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Phonebook.Data.Repositories
{
    /// <summary>
    /// Defining a single responsibility class, so that we can take advantage of our CRUD method(s) in repository class
    /// </summary>
    public class ContactRepository : Repository<Contact>, IContactRepository
    {
        private ApplicationDbContext dbContext = null;
        public ContactRepository(DbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext as ApplicationDbContext;
        }
    }
}
