﻿using Phonebook.Model;

namespace Phonebook.Data.Interfaces
{
    public interface IContactRepository : IRepository<Contact>
    {

    }
}
