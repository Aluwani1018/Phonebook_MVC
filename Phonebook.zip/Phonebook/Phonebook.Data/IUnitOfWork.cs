﻿using Phonebook.Data.Interfaces;

namespace Phonebook.Data
{
    public interface IUnitOfWork
    {
        IContactRepository Contacts { get; }
        int Save();
    }
}
