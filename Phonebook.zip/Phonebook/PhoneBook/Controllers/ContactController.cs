﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PhoneBook.MVC.Helper;
using PhoneBook.MVC.Models;

namespace PhoneBook.MVC.Controllers
{
    public class ContactController : Controller
    {
        HTTPHelper helper = null;
        string Url = string.Empty;

        public ContactController()
        {
            helper = new HTTPHelper();
            Url = "https://localhost:44330/absaapi";
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddEditContact(int id)
        {
            if (id == 0)
            {
                return View(new ContactViewModel());
            }
            else
            {
                try
                {
                    var result = helper.Get(new Uri($"{Url}/Contact/{id}"));

                    var contact = JsonConvert.DeserializeObject<ContactViewModel>(result);

                    return View(contact);

                }
                catch (Exception ex)
                {
                    throw ex;
                }
               
            }

        }
        [HttpGet]
        public IActionResult GetContacts()
        {

            try
            {
                var result = helper.Get(new Uri($"{Url}/Contact"));

                var contacts = JsonConvert.DeserializeObject<List<ContactViewModel>>(result);

                return Json(new { data = contacts });
            }
            catch (Exception ex )
            {
                throw ex;
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddEdit([FromBody] ContactViewModel contactViewModel)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (contactViewModel.Id == 0)
                {
                    var result = helper.PostJson(new Uri($"{Url}/Contact"), JsonConvert.SerializeObject(contactViewModel));

                    return Json(new { success = true, message = "Add new data success." });
                }
                else
                {

                    var result = helper.PostJson(new Uri($"{Url}/Contact"), JsonConvert.SerializeObject(contactViewModel));

                    return Json(new { success = true, message = "Edit data success." });
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = helper.DeleteJson(new Uri($"{Url}/Contact"), id.ToString());

            return Json(new { success = true, message = "Delete success." });
        }
    }
}