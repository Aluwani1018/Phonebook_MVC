﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBook.MVC.Helper
{

    /// <summary>
    /// Consumes Web Api's
    /// </summary>
    public class HTTPHelper
    {
        public String Get(Uri uri)
        {
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(uri);

            String result = execute(httpWReq);
            return result;
        }

        public String PostJson(Uri uri, String json)
        {
            byte[] bytes = UTF8Encoding.UTF8.GetBytes(json);

            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(uri);
            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/json";
            httpWReq.ContentLength = bytes.Length;
            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
            }

            String result = execute(httpWReq);
            return result;
        }

        public String DeleteJson(Uri uri, String json)
        {
            byte[] bytes = UTF8Encoding.UTF8.GetBytes(json);

            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(uri);
            httpWReq.Method = "DELETE";
            httpWReq.ContentType = "application/json";
            httpWReq.ContentLength = bytes.Length;
            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
            }

            String result = execute(httpWReq);
            return result;
        }

        private String execute(HttpWebRequest httpWReq)
        {
            HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
            String charset = response.CharacterSet;
            Stream inputStream = response.GetResponseStream();

            string responseString;
            if (String.IsNullOrWhiteSpace(charset))
            {
                responseString = new StreamReader(inputStream, true).ReadToEnd();
            }
            else
            {
                Encoding encoding = Encoding.GetEncoding(charset);
                responseString = new StreamReader(inputStream, encoding).ReadToEnd();
            }
            return responseString;
        }
    }
}
